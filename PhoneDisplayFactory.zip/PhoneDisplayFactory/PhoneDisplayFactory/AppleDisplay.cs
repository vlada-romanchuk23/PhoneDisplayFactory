﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneDisplayFactory
{
    public class AppleDisplay : MainDisplay
    {
        public override void ShowIcons()
        {
            Console.WriteLine("Показано іконки в стилі Apple.");
        }
    }

}
