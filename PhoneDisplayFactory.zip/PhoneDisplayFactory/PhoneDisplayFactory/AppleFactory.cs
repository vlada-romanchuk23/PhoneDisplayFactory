﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneDisplayFactory
{
    public class AppleFactory : IDisplayFactory
    {
        public MainDisplay CreateDisplay()
        {
            return new AppleDisplay();
        }
    }

}
