﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneDisplayFactory
{
    public abstract class MainDisplay : IMainDisplay
    {
        public abstract void ShowIcons(); // Унікальні іконки для кожного бренду

        public void OpenPhone()
        {
            Console.WriteLine("Відкрито програму телефону.");
        }

        public void OpenMessages()
        {
            Console.WriteLine("Відкрито програму повідомлень.");
        }
    }

}
