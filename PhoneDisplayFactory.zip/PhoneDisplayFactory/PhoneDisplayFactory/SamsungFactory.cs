﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneDisplayFactory
{
    public class SamsungFactory : IDisplayFactory
    {
        public MainDisplay CreateDisplay()
        {
            return new SamsungDisplay();
        }
    }

}
