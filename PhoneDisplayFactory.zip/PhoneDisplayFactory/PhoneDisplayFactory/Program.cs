﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneDisplayFactory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Вибір фабрики
            IDisplayFactory factory = new AppleFactory(); 
            MainDisplay display = factory.CreateDisplay();

            // Робота з дисплеєм
            display.ShowIcons();
            display.OpenPhone();
            display.OpenMessages();
        }
    }
}
